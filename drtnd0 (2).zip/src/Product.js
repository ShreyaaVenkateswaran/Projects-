import React from 'react';
import productImage from '../images/product-image.jpg';

function Product({ product }) {
  return (
    <div className="card">
      <img src={productImage} className="card-img-top" alt={product.title} />
      <div className="card-body">
        <h5 className="card-title">{product.title}</h5>
        <p className="card-text">{product.description}</p>
        <h6 className="card-subtitle mb-2 text-muted">${product.price}</h6>
        <div className="text-center">
          <span className="badge bg-secondary">{product.rating.rate} stars</span>
        </div>
      </div>
    </div>
  );
}

export default Product;
<div className="product">
  <img className="product__image" src={image} alt={title} />
  <h3 className="product__title">{title}</h3>
  <p className="product__price">${price}</p>
  <p className="product__description">{description}</p>
</div>

