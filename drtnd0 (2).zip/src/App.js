import React, { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

const App = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      const response = await axios.get("https://fakestoreapi.com/products");
      setProducts(response.data);
    };
    fetchProducts();
  }, []);

  return (
    <div className="container-fluid bg-light">
      <h1 className="text-center text-primary mt-3 mb-5">Products List</h1>
      <div className="row justify-content-center">
        {products.map((product) => (
          <div key={product.id} className="col-md-4 mb-4">
            <div className="card shadow-sm">
              <img
                src={product.image}
                alt={product.title}
                className="card-img-top"
              />
              <div className="card-body">
                <h5 className="card-title text-primary">{product.title}</h5>
                <p className="card-text">{product.description}</p>
                <p className="card-text text-danger font-weight-bold">
                  ${product.price}
                </p>
                <div className="d-flex align-items-center">
                  <div className="star-ratings-css">
                    <div
                      className="star-ratings-css-top"
                      style={{ width: `${product.rating.rate * 20}%` }}
                    >
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                    </div>
                    <div className="star-ratings-css-bottom">
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                    </div>
                  </div>
                  <span className="ml-2 text-secondary">
                    ({product.rating.count} reviews)
                  </span>
                </div>
              </div>
              <div className="card-footer bg-white">
                <button className="btn btn-primary btn-block">
                  Add to cart
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
